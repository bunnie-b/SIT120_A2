		
		
		
		var fname= "JHGLKI";
        var sname= "sladknn";
        var fln=fname.length;

        document.getElementById("string").innerHTML= "String method example. The length of the first name is " + fln;
		
		
		document.getElementById("test").innerHTML=
			"Test scores are: " + a + "| " + b + "| " + c + ". Your AVERAGE is: " + AVG;