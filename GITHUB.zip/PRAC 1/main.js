
	new Vue({
		el:'#app',

		data:{
			todos:[
				{text: "Learn JavaScript", done:true},
				{text: "Learn HTML", done:true },
				{text: "Learn CSS", done:true }
				]
			 },
		
			   methods: {
					toggle: function(todo){
					todo.done= !todo.done;
				},
			  	  addItem: function (newItem){
					var value= this.newItem && this.newItem.trim()
					this.todos.push({
						text: value,
						done: false})

					this.newItem='';
			}
			
		}
		
	})
	
	
	